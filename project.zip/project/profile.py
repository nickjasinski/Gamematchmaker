from game import Game

class Profile:
    def __init__(self, profileId: int, name: str, favoriteGame: Game, bio: str):
        self.profileId = profileId
        self.name = name
        self.favoriteGame = favoriteGame
        self.bio = bio

    def editProfile(self, name: str, favoriteGame: Game, bio: str) -> bool:
        pass
