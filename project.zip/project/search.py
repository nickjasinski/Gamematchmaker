from typing import List

from game import Game
from user import User

class Search:
    def searchByTitle(self, title: str) -> List[Game]:
        pass

    def searchUserByUsername(self, username: str) -> List[User]:
        pass