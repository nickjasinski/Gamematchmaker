DB_CONFIG = {
    "host": "gamematch-db.cx0g2w2aid3a.us-east-1.rds.amazonaws.com",
    "database": "postgres",
    "user": "dbadmin",
    "password": "password7654321!!",
    "port": 5432
}
