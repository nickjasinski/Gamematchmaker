from typing import List

from game import Game

class Wishlist:
    def __init__(self, weblistID: int):
        self.weblistID = weblistID

    def addGame(self, game: Game) -> bool:
        pass

    def removeGame(self, game: Game) -> bool:
        pass

    def retrieveWishlist(self) -> List[Game]:
        pass