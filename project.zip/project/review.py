
class Review:
    def __init__(self, reviewId: int, content: str, rating: int):
        self.reviewId = reviewId
        self.content = content
        self.rating = rating

    def like(self):
        pass

    def dislike(self):
        pass