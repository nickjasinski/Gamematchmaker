
class Database:
    def __init__(self, name: str):
        self.name = name

    def getUser():
        pass

    def getProfile():
        pass

    def getGame():
        pass

    def getWishlist():
        pass