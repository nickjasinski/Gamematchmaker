
class Genre:
    def __init__(self, genreId: int, name: str):
        self.genreId = genreId
        self.name = name

    def getGenreName(self, genreId: str) -> str:
        pass